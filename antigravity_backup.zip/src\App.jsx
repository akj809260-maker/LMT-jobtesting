import React, { useState } from 'react';
import { Box } from 'lucide-react';
import UploadZone from './components/UploadZone.jsx';
import LoadingOverlay from './components/LoadingOverlay.jsx';
import Viewer3D from './components/Viewer3D.jsx';

function App() {
  const [appState, setAppState] = useState('idle'); // 'idle', 'loading', 'viewer'
  const [file, setFile] = useState(null);
  const [imageUrl, setImageUrl] = useState(null);

  const handleUpload = (uploadedFile) => {
    setFile(uploadedFile);

    // Create an object URL from the uploaded file to act as the 2D texture source
    const url = URL.createObjectURL(uploadedFile);
    setImageUrl(url);

    setAppState('loading');

    // Mock AI processing delay
    setTimeout(() => {
      setAppState('viewer');
    }, 3000);
  };

  return (
    <div className="min-h-screen bg-zinc-950 flex flex-col relative overflow-hidden font-sans">
      {/* Background Gradients */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
        <div className="absolute -top-[10%] -right-[10%] w-[50%] h-[50%] bg-indigo-600/20 blur-[120px] rounded-full mix-blend-screen" />
        <div className="absolute -bottom-[20%] -left-[10%] w-[60%] h-[60%] bg-fuchsia-600/10 blur-[120px] rounded-full mix-blend-screen" />
      </div>

      {/* Header */}
      <header className="relative z-10 flex items-center justify-between px-8 py-6 border-b border-white/5 backdrop-blur-md bg-black/20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Box className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-white/60">
            Antigravity 3D
          </h1>
        </div>
        <nav className="hidden sm:flex items-center gap-6 text-sm font-medium text-zinc-400">
          <a href="#" className="hover:text-white transition-colors">Documentation</a>
          <a href="#" className="hover:text-white transition-colors">Gallery</a>
          <button className="px-4 py-2 rounded-lg bg-white/5 hover:bg-white/10 text-white border border-white/10 transition-all">
            Sign In
          </button>
        </nav>
      </header>

      {/* Main Content */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center p-6">
        {appState === 'idle' && (
          <div className="w-full max-w-3xl flex flex-col items-center text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
            <h2 className="text-4xl md:text-5xl font-bold tracking-tight mb-4 shadow-black/50 text-balance">
              Transform 2D into <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-fuchsia-400">Interactive 3D</span>
            </h2>
            <p className="text-zinc-400 text-lg mb-10 max-w-xl text-balance">
              Upload an image and let our AI agents do the heavy lifting. Preview your model directly in your browser with standard OrbitControls.
            </p>
            <UploadZone onUpload={handleUpload} />
          </div>
        )}

        {appState === 'loading' && (
          <LoadingOverlay fileName={file?.name || "image.png"} />
        )}

        {appState === 'viewer' && (
          <div className="w-full h-full flex-1 rounded-2xl overflow-hidden border border-white/10 bg-black/50 shadow-2xl backdrop-blur-sm animate-in zoom-in-95 duration-500 relative">
            <Viewer3D imageUrl={imageUrl} />
            <div className="absolute top-4 left-4 z-20 flex gap-2">
              <button
                onClick={() => {
                  if (imageUrl) URL.revokeObjectURL(imageUrl);
                  setFile(null);
                  setImageUrl(null);
                  setAppState('idle');
                }}
                className="px-4 py-2 rounded-lg bg-black/60 backdrop-blur-md border border-white/10 text-white text-sm font-medium hover:bg-black/80 transition-colors"
              >
                Back to Upload
              </button>
            </div>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 pointer-events-none">
              <div className="px-4 py-2 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-white/70 text-sm font-medium flex items-center gap-2">
                <span>Left click to rotate</span>
                <span className="w-1 h-1 rounded-full bg-white/30" />
                <span>Scroll to zoom</span>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
