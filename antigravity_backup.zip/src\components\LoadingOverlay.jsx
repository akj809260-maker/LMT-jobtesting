import React from 'react';
import { Loader2, Zap } from 'lucide-react';

export default function LoadingOverlay({ fileName }) {
    return (
        <div className="w-full max-w-md flex flex-col justify-center items-center text-center p-8 rounded-3xl bg-zinc-900/40 border border-white/5 backdrop-blur-xl animate-in fade-in zoom-in-95 duration-500 shadow-2xl">
            <div className="relative mb-8">
                {/* Glow effect */}
                <div className="absolute inset-0 bg-indigo-500 rounded-full blur-xl opacity-20 animate-[pulse_3s_cubic-bezier(0.4,0,0.6,1)_infinite]" />

                <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-zinc-800 to-zinc-700 border border-zinc-600 flex items-center justify-center relative z-10 shadow-inner">
                    <Loader2 className="w-10 h-10 text-indigo-400 animate-spin" />
                </div>

                <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-indigo-500 flex items-center justify-center border-4 border-zinc-900 z-20">
                    <Zap className="w-3 h-3 text-white" />
                </div>
            </div>

            <h3 className="text-2xl font-bold text-white mb-2 tracking-tight">
                Generating 3D AI Model
            </h3>
            <p className="text-zinc-400 text-sm mb-6 max-w-[250px]">
                Processing <span className="text-zinc-300 font-medium truncate max-w-[100px] inline-block align-bottom">{fileName}</span>... This might take a few moments.
            </p>

            <div className="w-full h-1.5 bg-zinc-800 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-indigo-500 to-fuchsia-500 w-full animate-[progress_3s_ease-in-out_infinite] origin-left" style={{ animationTimingFunction: 'cubic-bezier(0.4, 0, 0.2, 1)' }} />
            </div>

            <style>{`
        @keyframes progress {
          0% { transform: scaleX(0); transform-origin: left; }
          40% { transform: scaleX(1); transform-origin: left; }
          50% { transform: scaleX(1); transform-origin: right; }
          90% { transform: scaleX(0); transform-origin: right; }
          100% { transform: scaleX(0); transform-origin: left; }
        }
      `}</style>
        </div>
    );
}
