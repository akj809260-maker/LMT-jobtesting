import React, { useCallback, useState } from 'react';
import { UploadCloud, Image as ImageIcon } from 'lucide-react';

export default function UploadZone({ onUpload }) {
    const [isDragging, setIsDragging] = useState(false);

    const handleDrag = useCallback((e) => {
        e.preventDefault();
        e.stopPropagation();
        if (e.type === 'dragenter' || e.type === 'dragover') {
            setIsDragging(true);
        } else if (e.type === 'dragleave') {
            setIsDragging(false);
        }
    }, []);

    const handleDrop = useCallback((e) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);

        if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
            onUpload(e.dataTransfer.files[0]);
        }
    }, [onUpload]);

    const handleChange = (e) => {
        if (e.target.files && e.target.files.length > 0) {
            onUpload(e.target.files[0]);
        }
    };

    return (
        <div
            className={`w-full relative group transition-all duration-300 ${isDragging ? 'scale-[1.02]' : 'scale-100'}`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
        >
            <div className={`absolute inset-0 rounded-3xl bg-gradient-to-br from-indigo-500/20 to-fuchsia-500/20 blur-xl transition-opacity duration-300 ${isDragging ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`} />

            <div className={`relative p-10 md:p-16 w-full rounded-3xl border-2 border-dashed flex flex-col items-center justify-center gap-4 transition-colors duration-300 bg-zinc-900/50 backdrop-blur-sm ${isDragging ? 'border-indigo-500 bg-indigo-500/5' : 'border-zinc-700 hover:border-zinc-500 group-hover:bg-zinc-800/50'
                }`}>

                <div className="w-16 h-16 rounded-2xl bg-zinc-800 flex items-center justify-center shadow-inner mb-2 group-hover:scale-110 transition-transform duration-300 pointer-events-none">
                    <UploadCloud className="w-8 h-8 text-indigo-400" />
                </div>

                <div className="text-center pointer-events-none">
                    <p className="text-xl font-medium text-white mb-1">
                        Drag & drop an image here
                    </p>
                    <p className="text-sm text-zinc-400">
                        or click to browse from your computer
                    </p>
                </div>

                <div className="flex items-center gap-4 mt-4 opacity-70 pointer-events-none">
                    <div className="flex items-center gap-1.5 text-xs text-zinc-500 bg-zinc-900 px-3 py-1.5 rounded-md border border-zinc-800">
                        <ImageIcon className="w-3 h-3" /> JPG, PNG, WEBP
                    </div>
                </div>

                <input
                    type="file"
                    className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    accept="image/*"
                    onChange={handleChange}
                />
            </div>
        </div>
    );
}
