import React, { useRef, useMemo, Suspense } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Stage, Center, useTexture, ContactShadows, Float, MeshDistortMaterial } from '@react-three/drei';
import * as THREE from 'three';

function ExtrudedImage({ imageUrl }) {
    const texture = useTexture(imageUrl);
    const meshRef = useRef();

    // Adjust texture color space for modern standard materials
    texture.colorSpace = THREE.SRGBColorSpace;

    // Compute dimensions relative to the aspect ratio to maintain image proportions
    const imgAspect = texture.image ? texture.image.width / texture.image.height : 1;
    const width = imgAspect > 1 ? 5 : 5 * imgAspect;
    const height = imgAspect > 1 ? 5 / imgAspect : 5;
    const depth = 0.5; // Giving the thickness of "0.5 units"

    const materials = useMemo(() => {
        // Front face mapping the generated texture logo
        const frontMat = new THREE.MeshStandardMaterial({ map: texture, roughness: 0.2, metalness: 0.5 });
        // Back face (assuming we want it to carry the logo backwards)
        const backMat = new THREE.MeshStandardMaterial({ map: texture, roughness: 0.2, metalness: 0.5 });
        // Side faces are a solid grey to mimic a sturdy physical 3D sign extrusion
        const sideMat = new THREE.MeshStandardMaterial({ color: '#27272a', roughness: 0.5 });

        // Material Array index order for BoxGeometry: right, left, top, bottom, front, back
        return [sideMat, sideMat, sideMat, sideMat, frontMat, backMat];
    }, [texture]);

    useFrame((state, delta) => {
        if (meshRef.current) {
            meshRef.current.rotation.y += delta * 0.2;
        }
    });

    return (
        <Center>
            <mesh ref={meshRef} castShadow receiveShadow geometry={new THREE.BoxGeometry(width, height, depth)} material={materials} />
        </Center>
    );
}

function PlaceholderModel() {
    const meshRef = useRef();

    useFrame((state, delta) => {
        if (meshRef.current) {
            meshRef.current.rotation.y += delta * 0.2;
        }
    });

    return (
        <Float speed={2} rotationIntensity={0.5} floatIntensity={1}>
            <mesh ref={meshRef} castShadow receiveShadow>
                <icosahedronGeometry args={[1.5, 5]} />
                <MeshDistortMaterial
                    color="#8b5cf6"
                    envMapIntensity={1}
                    clearcoat={1}
                    clearcoatRoughness={0.1}
                    metalness={0.5}
                    roughness={0.2}
                    distort={0.3}
                    speed={2}
                />
            </mesh>
        </Float>
    );
}

export default function Viewer3D({ imageUrl }) {
    return (
        <div className="w-full h-full bg-zinc-950/50 cursor-grab active:cursor-grabbing">
            <Canvas shadows camera={{ position: [0, 0, 8], fov: 45 }}>
                <color attach="background" args={['transparent']} />

                <Suspense fallback={null}>
                    {/* The Stage component sets up professional lighting, centering, and scaling immediately */}
                    <Stage environment="city" intensity={0.5} adjustCamera={1.2}>
                        {imageUrl ? <ExtrudedImage imageUrl={imageUrl} /> : <PlaceholderModel />}
                    </Stage>
                </Suspense>

                {/* Ground plane shadow */}
                <ContactShadows
                    position={[0, -2.5, 0]}
                    opacity={0.5}
                    scale={20}
                    blur={2.5}
                    far={4}
                />

                {/* Interactive Controls */}
                <OrbitControls
                    makeDefault
                    enablePan={false}
                    enableZoom={true}
                    minDistance={3}
                    maxDistance={12}
                    autoRotate={true}
                    autoRotateSpeed={1}
                />
            </Canvas>
        </div>
    );
}
